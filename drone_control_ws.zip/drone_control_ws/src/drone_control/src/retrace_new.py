#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import rospy
import tty, termios, sys, select
from mavros_msgs.msg import ManualControl
from mavros_msgs.srv import CommandBool, SetMode, CommandTOL
from sensor_msgs.msg import NavSatFix
import time

class DroneController:
    def __init__(self):
        # Initialize node
        rospy.init_node('keyboard_control_drone', anonymous=True)

        # Publishers
        self.manual_control_pub = rospy.Publisher('/mavros/manual_control/send', ManualControl, queue_size=10)

        # Service proxies
        self.arm_service = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.set_mode_service = rospy.ServiceProxy('/mavros/set_mode', SetMode)
        self.takeoff_service = rospy.ServiceProxy('/mavros/cmd/takeoff', CommandTOL)
        self.land_service = rospy.ServiceProxy('/mavros/cmd/land', CommandTOL)

        # GPS data for retracing path
        self.current_gps = None

        # Control variables
        self.throttle = 500
        self.yaw = 0
        self.pitch = 0
        self.roll = 0
        self.step = 600

    def arm_drone(self):
        try:
            self.arm_service(True)
            rospy.loginfo("Drone armed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Arming failed: {e}")

    def disarm_drone(self):
        try:
            self.arm_service(False)
            rospy.loginfo("Drone disarmed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Disarming failed: {e}")

    def set_mode(self, mode):
        try:
            response = self.set_mode_service(custom_mode=mode)
            if response.mode_sent:
                rospy.loginfo(f"Mode set to {mode}")
            else:
                rospy.logwarn(f"Failed to set mode to {mode}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Setting mode failed: {e}")

    def takeoff(self, altitude=10.0):
        try:
            self.takeoff_service(min_pitch=0, yaw=0, altitude=altitude)
            rospy.loginfo(f"Drone taking off to {altitude} meters")
        except rospy.ServiceException as e:
            rospy.logerr(f"Takeoff failed: {e}")

    def land(self):
        try:
            self.land_service(min_pitch=0, yaw=0, altitude=0)
            rospy.loginfo("Drone landing")
        except rospy.ServiceException as e:
            rospy.logerr(f"Landing failed: {e}")

    def gps_callback(self, msg):
        """ Store GPS coordinates for retracing """
        self.current_gps = (msg.latitude, msg.longitude, msg.altitude)
        rospy.loginfo(f"Current GPS: {self.current_gps}")

    def get_key(self):
        settings = termios.tcgetattr(sys.stdin)
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return key

    def control_loop(self):
        self.set_mode('MANUAL')
        rospy.sleep(1)
        self.arm_drone()

        # Subscribe to GPS data
        rospy.Subscriber('/mavros/global_position/global', NavSatFix, self.gps_callback)

        while not rospy.is_shutdown():
            key = self.get_key()
            if key:
                if key == 'w': self.pitch = self.step
                elif key == 's': self.pitch = -self.step
                elif key == 'a': self.roll = -self.step
                elif key == 'd': self.roll = self.step
                elif key == 'q': self.yaw = self.step
                elif key == 'e': self.yaw = -self.step
                elif key == '8': self.throttle = 800
                elif key == '2': self.throttle = -800
                elif key == '1': self.arm_drone()
                elif key == 'D': self.disarm_drone()
                elif key == 't': self.takeoff(altitude=10)  # Take off
                elif key == 'l': self.land()  # Land
                elif key == 'r':  # Retrace the path
                    if self.current_gps:
                        rospy.loginfo(f"Retracing path to {self.current_gps}")
                        self.set_mode('AUTO.MISSION')
                        rospy.sleep(2)
                        # You would set waypoints here or use a drone command to move back to the initial point
                        # For now, we simulate a return to the initial point using the recorded GPS
                        self.set_mode('AUTO.LAND')
                        rospy.sleep(10)
                        self.set_mode('MANUAL')  # Return to manual mode after retracing

                # Publish manual control command
                self.manual_control_pub.publish(ManualControl(
                    x=self.pitch,
                    y=self.roll,
                    z=self.throttle,
                    r=self.yaw
                ))
                rospy.loginfo(f"throttle = {self.throttle}, yaw = {self.yaw}, pitch = {self.pitch}, roll = {self.roll}")

                # Reset control variables
                self.yaw, self.pitch, self.roll, self.throttle = 0, 0, 500, 500
                rospy.sleep(0.1)

if __name__ == '__main__':
    controller = DroneController()
    controller.control_loop()

