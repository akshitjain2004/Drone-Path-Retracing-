#!/usr/bin/env python3

import rospy
from mavros_msgs.srv import SetMode, CommandBool
from mavros_msgs.msg import PositionTarget
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import NavSatFix
import time

class DroneController:
    def __init__(self):
        rospy.init_node('drone_controller', anonymous=True)
        self.set_mode_service = rospy.ServiceProxy('/mavros/set_mode', SetMode)
        self.arm_service = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.position_pub = rospy.Publisher('/mavros/setpoint_position/global', PositionTarget, queue_size=10)

        # Waypoints (example)
        self.waypoints = [
            (37.7749, -122.4194, 100),  # Home position (start)
            (37.7750, -122.4195, 100),  # Waypoint 1
            (37.7751, -122.4196, 100)   # Waypoint 2
        ]
        
        self.current_waypoint_idx = 0
        self.is_mission_started = False

    def arm_drone(self):
        try:
            self.arm_service(True)
            rospy.loginfo("Drone armed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to arm drone: {e}")

    def disarm_drone(self):
        try:
            self.arm_service(False)
            rospy.loginfo("Drone disarmed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to disarm drone: {e}")

    def set_mode(self, mode):
        try:
            response = self.set_mode_service(custom_mode=mode)
            if response.mode_sent:
                rospy.loginfo(f"Mode set to {mode}")
            else:
                rospy.logwarn(f"Failed to set mode to {mode}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to set mode: {e}")

    def move_to_waypoint(self, waypoint):
        target_position = PositionTarget()
        target_position.coordinate_frame = PositionTarget.FRAME_GLOBAL_INT
        target_position.type_mask = PositionTarget.IGNORE_YAW_RATE
        target_position.position.x = waypoint[0]  # Longitude
        target_position.position.y = waypoint[1]  # Latitude
        target_position.position.z = waypoint[2]  # Altitude
        self.position_pub.publish(target_position)
        rospy.loginfo(f"Moving to waypoint: {waypoint}")

    def retrace_path(self):
        rospy.loginfo("Retracing path to home position")
        for i in range(len(self.waypoints)-1, -1, -1):
            self.move_to_waypoint(self.waypoints[i])
            rospy.sleep(5)

    def control_loop(self):
        while not rospy.is_shutdown():
            if not self.is_mission_started:
                rospy.loginfo("Starting mission: Arming and Takeoff")
                self.arm_drone()
                self.set_mode('GUIDED')
                rospy.sleep(1)

                self.set_mode('AUTO.TAKEOFF')
                rospy.sleep(3)

                self.move_to_waypoint(self.waypoints[self.current_waypoint_idx])
                self.is_mission_started = True

            rospy.sleep(5)

            self.current_waypoint_idx += 1
            if self.current_waypoint_idx < len(self.waypoints):
                self.move_to_waypoint(self.waypoints[self.current_waypoint_idx])
            else:
                rospy.loginfo("Mission completed. Returning home.")
                self.retrace_path()
                self.set_mode('AUTO.LAND')
                self.disarm_drone()
                break

            rospy.sleep(1)

if __name__ == '__main__':
    try:
        controller = DroneController()
        controller.control_loop()
    except rospy.ROSInterruptException:
        pass

