#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import rospy
import tty, termios, sys, select
from mavros_msgs.msg import ManualControl
from mavros_msgs.srv import CommandBool, SetMode
from sensor_msgs.msg import NavSatFix

class DroneController:
    def __init__(self):
     
        rospy.init_node('keyboard_control_drone', anonymous=True)

        #publishers
        self.manual_control_pub = rospy.Publisher('/mavros/manual_control/send', ManualControl, queue_size=10)

        #service-procxy
        self.arm_service = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.set_mode_service = rospy.ServiceProxy('/mavros/set_mode', SetMode)

        #control var
        self.throttle = 500
        self.yaw = 0
        self.pitch = 0
        self.roll = 0
        self.step = 600

        # storing waypoints here
        self.waypoints = []

        #gps insitialization
        self.current_gps = None

        #sub to gps
        rospy.Subscriber('/mavros/global_position/global', NavSatFix, self.gps_callback)

        #to print gps data
        rospy.Timer(rospy.Duration(1), self.print_gps_data)

    def arm_drone(self):
        try:
            self.arm_service(True)
            rospy.loginfo("Drone armed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Arming failed: {e}")

    def disarm_drone(self):
        try:
            self.arm_service(False)
            rospy.loginfo("Drone disarmed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Disarming failed: {e}")

    def set_mode(self, mode):
        try:
            response = self.set_mode_service(custom_mode=mode)
            if response.mode_sent:
                rospy.loginfo(f"Mode set to {mode}")
            else:
                rospy.logwarn(f"Failed to set mode to {mode}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Setting mode failed: {e}")

    def gps_callback(self, msg):
        #store gps after takeoff
        if len(self.waypoints) == 0: 
            self.waypoints.append((msg.latitude, msg.longitude, msg.altitude))
            rospy.loginfo(f"Stored takeoff waypoint: {self.waypoints[0]}")
        
        #update gps data
        self.current_gps = (msg.latitude, msg.longitude, msg.altitude)

    def print_gps_data(self, event):
        if self.current_gps:
            latitude, longitude, altitude = self.current_gps
            rospy.loginfo(f"Current GPS Data: Lat: {latitude}, Lon: {longitude}, Alt: {altitude}")
        else:
            rospy.logwarn("Waiting for GPS data...")

    def retrace_path(self):
        if len(self.waypoints) > 0:
            rospy.loginfo(f"Retracing path: {self.waypoints}")
            #retrace 
            for waypoint in reversed(self.waypoints):  # Start from landing point and move towards takeoff
                latitude, longitude, altitude = waypoint
                rospy.loginfo(f"Retracing to waypoint: {waypoint}")
                
               
                self.move_to_waypoint(latitude, longitude, altitude)
                rospy.sleep(3)  # Simulating movement between waypoints
        else:
            rospy.logwarn("No waypoints stored for retracing the path!")

    def move_to_waypoint(self, latitude, longitude, altitude):
    
        rospy.loginfo(f"Moving to: Lat: {latitude}, Lon: {longitude}, Alt: {altitude}")
      
        self.set_mode('AUTO.MISSION')  # Correct autopilot mode
        rospy.sleep(1)
        
        rospy.loginfo(f"Arrived at waypoint: {latitude}, {longitude}, {altitude}")

    def get_key(self):
        settings = termios.tcgetattr(sys.stdin)
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return key

    def control_loop(self):
        self.set_mode('MANUAL')
        rospy.sleep(1)
        self.arm_drone()

        while not rospy.is_shutdown():
            key = self.get_key()
            if key:
                if key == 'w': self.pitch = self.step
                elif key == 's': self.pitch = -self.step
                elif key == 'a': self.roll = -self.step
                elif key == 'd': self.roll = self.step
                elif key == 'q': self.yaw = self.step
                elif key == 'e': self.yaw = -self.step
                elif key == '8': self.throttle = 800
                elif key == '2': self.throttle = -800
                elif key == '1': self.arm_drone()
                elif key == 'D': self.disarm_drone()
                elif key == 't': self.set_mode('AUTO.TAKEOFF')  # Takeoff
                elif key == 'l': self.set_mode('AUTO.LAND')     # Land
                elif key == 'r': self.retrace_path()  # Retrace path when 'r' is pressed


                self.manual_control_pub.publish(ManualControl(
                    x=self.pitch,
                    y=self.roll,
                    z=self.throttle,
                    r=self.yaw
                ))
                rospy.loginfo(f"throttle = {self.throttle}, yaw = {self.yaw}, pitch = {self.pitch}, roll = {self.roll}")


                self.yaw, self.pitch, self.roll, self.throttle = 0, 0, 500, 500
                rospy.sleep(0.1)

if __name__ == '__main__':
    controller = DroneController()
    controller.control_loop()

