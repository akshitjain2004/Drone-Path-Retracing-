#!/usr/bin/env python3

import rospy
from mavros_msgs.srv import SetMode, CommandBool
from mavros_msgs.msg import State
from geographic_msgs.msg import GeoPoseStamped
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import Header
from pynput.keyboard import Listener

class DroneController:
    def __init__(self):
        rospy.init_node('drone_controller', anonymous=True)

        # Set up the MAVROS services and publishers
        self.set_mode_service = rospy.ServiceProxy('/mavros/set_mode', SetMode)
        self.arm_service = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.position_pub = rospy.Publisher('/mavros/setpoint_position/global', GeoPoseStamped, queue_size=10)
        self.state_sub = rospy.Subscriber('/mavros/state', State, self.state_callback)
        self.gps_sub = rospy.Subscriber('/mavros/global_position/global', NavSatFix, self.gps_callback)

        # Variables to track the drone's state and position
        self.current_state = State()
        self.gps_position = None
        self.takeoff_position = None  # Store takeoff position to retrace path
        self.current_position = [0, 0, 0]  # Latitude, Longitude, Altitude
        self.is_mission_started = False
        self.mode = 'MANUAL'  # Set to MANUAL mode for manual control

        # Keyboard control variables
        self.throttle = 0.0  # Control altitude
        self.pitch = 0.0  # Control forward/backward movement
        self.roll = 0.0  # Control left/right movement
        self.yaw = 0.0  # Control rotation (yaw)

    def state_callback(self, msg):
        """Callback to capture the drone's state."""
        self.current_state = msg

    def gps_callback(self, msg):
        """Callback to capture the GPS data."""
        self.gps_position = msg
        self.current_position = [self.gps_position.latitude, self.gps_position.longitude, self.gps_position.altitude]

    def arm_drone(self):
        """Arms the drone."""
        try:
            self.arm_service(True)
            rospy.loginfo("Drone armed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to arm drone: {e}")

    def disarm_drone(self):
        """Disarms the drone."""
        try:
            self.arm_service(False)
            rospy.loginfo("Drone disarmed successfully")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to disarm drone: {e}")

    def set_mode(self, mode):
        """Sets the flight mode of the drone."""
        try:
            response = self.set_mode_service(custom_mode=mode)
            if response.mode_sent:
                rospy.loginfo(f"Mode set to {mode}")
            else:
                rospy.logwarn(f"Failed to set mode to {mode}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to set mode: {e}")

    def move_to_waypoint(self, waypoint):
        """Moves the drone to a specified waypoint (latitude, longitude, altitude)."""
        geo_pose = GeoPoseStamped()
        geo_pose.header = Header()
        geo_pose.header.stamp = rospy.Time.now()

        # Set the target position in geographic coordinates (lat, lon, alt)
        geo_pose.pose.position.latitude = waypoint[0]
        geo_pose.pose.position.longitude = waypoint[1]
        geo_pose.pose.position.altitude = waypoint[2]

        # Publish the waypoint to the global setpoint position topic
        self.position_pub.publish(geo_pose)
        rospy.loginfo(f"Moving to waypoint: {waypoint}")

    def record_takeoff_position(self):
        """Records the drone's position at takeoff to use as the origin."""
        if self.gps_position:
            self.takeoff_position = [self.gps_position.latitude, self.gps_position.longitude, self.gps_position.altitude]
            rospy.loginfo(f"Takeoff position recorded: {self.takeoff_position}")
        else:
            rospy.logwarn("GPS data not available for recording takeoff position.")

    def retrace_path(self):
        """Retraces the drone's path from the landing point to the takeoff point."""
        rospy.loginfo("Retracing path to takeoff position.")
        if self.takeoff_position:
            self.move_to_waypoint(self.takeoff_position)
        else:
            rospy.logwarn("Takeoff position not recorded. Cannot retrace path.")

    def control_loop(self):
        """Controls the drone to follow the mission and retrace the path."""
        while not rospy.is_shutdown():
            # Wait for the drone to be armed and in MANUAL mode
            if not self.is_mission_started:
                rospy.loginfo("Starting mission: Arming and Takeoff")
                self.arm_drone()
                self.set_mode(self.mode)  # Keep in MANUAL mode for manual control
                rospy.sleep(1)

                self.record_takeoff_position()
                self.is_mission_started = True

            rospy.sleep(1)
            self.move_drone()

           

